"""
Fideon RunPod Server
====================
Deploy this entire ai-ml/ folder to /workspace/ai-ml/ on the pod.

Endpoints:
  GET  /health                        — liveness
  GET  /readyz                        — readiness
  POST /upload                        — receive a PDF, save to /workspace/uploads/
  GET  /upload/{upload_id}/status     — poll upload record
  GET  /upload/{upload_id}/file       — download raw PDF bytes
  GET  /uploads                       — list all uploads (admin)
  POST /process/{upload_id}           — start Surya OCR job (returns job_id immediately)
  GET  /process/{job_id}/status       — poll OCR job status + results
  GET  /jobs                          — list all OCR jobs (admin)
  POST /extract/{upload_id}           — full ACORD extraction (Surya OCR + Qwen VL)

  Training / Fine-tuning:
  POST /training-samples              — store corrected extraction sample
  GET  /training-samples              — list stored samples + count
  POST /finetune/start                — ingest pending samples + launch run_cycle()
  GET  /finetune/jobs/{job_id}        — poll fine-tuning job status
  GET  /finetune/jobs                 — list all fine-tuning jobs
  GET  /registry/versions             — SLM version history

Start via:  python server.py  (or use start.sh)
"""
from __future__ import annotations

import json
import os
import sys
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

# Ensure ai-ml/fine_tuning is resolved before any /workspace/fine_tuning that
# may exist from the backend. Insert the directory containing this file (i.e.
# /workspace/ai-ml) at the front of sys.path so `import fine_tuning` always
# picks up the correct QLoRA pipeline package.
_THIS_DIR = str(Path(__file__).parent.resolve())
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

import threading
import uvicorn
from fastapi import Body, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "/workspace/uploads"))
TRAINING_SAMPLES_FILE = Path(os.getenv("TRAINING_SAMPLES_FILE", "/workspace/training_samples.jsonl"))
PENDING_SHARE_DIR = Path("/workspace/fine_tuning/pending_shares")
PORT = int(os.getenv("UPLOAD_SERVER_PORT", "8080"))
OCR_WORKERS = int(os.getenv("OCR_WORKERS", "1"))  # 1 GPU → 1 worker

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# In-memory stores
# ---------------------------------------------------------------------------
_uploads: Dict[str, Dict[str, Any]] = {}
_ocr_jobs: Dict[str, Dict[str, Any]] = {}

# Share-gradients jobs (user-triggered SeaweedFS upload after local training)
_share_jobs: Dict[str, Dict[str, Any]] = {}
_share_jobs_lock = threading.Lock()

# Thread pool for background OCR (GPU work runs in a thread, not async)
_executor = ThreadPoolExecutor(max_workers=OCR_WORKERS)

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------
app = FastAPI(title="Fideon RunPod Server", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """
    Trigger background model warmup on startup.
    This loads the heavy Qwen2-VL model into GPU VRAM immediately so that the
    first extraction request doesn't time out.
    """
    import threading
    from extractor import _load_qwen
    print("[server] Triggering background model warmup...")
    threading.Thread(target=_load_qwen, daemon=True).start()


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------
@app.get("/health")
def health() -> Dict[str, Any]:
    return {
        "status": "ok",
        "upload_dir": str(UPLOAD_DIR),
        "total_uploads": len(_uploads),
        "total_jobs": len(_ocr_jobs),
        "disk_files": len(list(UPLOAD_DIR.iterdir())) if UPLOAD_DIR.exists() else 0,
    }


@app.get("/readyz")
def readyz() -> Dict[str, str]:
    return {"status": "ready"}


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------
@app.post("/upload")
async def upload_pdf(
    file: UploadFile = File(...),
    form_type: str = "25",
) -> Dict[str, Any]:
    if not file.filename:
        raise HTTPException(status_code=400, detail="filename is required")

    upload_id = str(uuid.uuid4())
    safe_name = Path(file.filename).name
    dest = UPLOAD_DIR / f"{upload_id}_{safe_name}"

    content = await file.read()
    if not content:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    dest.write_bytes(content)

    record: Dict[str, Any] = {
        "upload_id": upload_id,
        "filename": safe_name,
        "form_type": form_type,
        "content_type": file.content_type or "application/octet-stream",
        "size_bytes": len(content),
        "path": str(dest),
        "status": "uploaded",
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
    }
    _uploads[upload_id] = record
    return record


@app.get("/upload/{upload_id}/status")
def upload_status(upload_id: str) -> Dict[str, Any]:
    record = _uploads.get(upload_id)
    if record:
        return record

    # Recover from disk after pod restart
    matches = list(UPLOAD_DIR.glob(f"{upload_id}_*"))
    if matches:
        f = matches[0]
        recovered: Dict[str, Any] = {
            "upload_id": upload_id,
            "filename": f.name.split("_", 1)[-1] if "_" in f.name else f.name,
            "path": str(f),
            "size_bytes": f.stat().st_size,
            "status": "uploaded",
            "note": "recovered from disk after pod restart",
        }
        _uploads[upload_id] = recovered
        return recovered

    raise HTTPException(status_code=404, detail=f"Upload '{upload_id}' not found")


@app.get("/upload/{upload_id}/file")
def download_upload_file(upload_id: str) -> Response:
    """Return the raw PDF bytes for a previously uploaded file."""
    record = _uploads.get(upload_id)
    if not record:
        matches = list(UPLOAD_DIR.glob(f"{upload_id}_*"))
        if matches:
            record = {"upload_id": upload_id, "path": str(matches[0]), "filename": matches[0].name.split("_", 1)[-1], "status": "uploaded"}
            _uploads[upload_id] = record
        else:
            raise HTTPException(status_code=404, detail=f"Upload '{upload_id}' not found")

    pdf_path = Path(record.get("path", ""))
    if not pdf_path.exists():
        raise HTTPException(status_code=404, detail=f"PDF file not on disk: {pdf_path}")

    return Response(content=pdf_path.read_bytes(), media_type="application/pdf")


@app.get("/uploads")
def list_uploads() -> List[Dict[str, Any]]:
    return list(_uploads.values())


# ---------------------------------------------------------------------------
# Surya OCR — background job runner
# ---------------------------------------------------------------------------
def _run_ocr_job(job_id: str, pdf_path: str) -> None:
    """
    Runs in a thread-pool worker.
    Updates _ocr_jobs[job_id] with status transitions and final results.
    """
    job = _ocr_jobs[job_id]

    try:
        job["status"] = "loading_model"
        job["loading_model_at"] = datetime.now(timezone.utc).isoformat()

        from surya_runner import run_surya_on_pdf  # lazy: heavy import

        job["status"] = "processing"
        job["processing_at"] = datetime.now(timezone.utc).isoformat()

        result = run_surya_on_pdf(pdf_path)

        if result.get("error"):
            job["status"] = "failed"
            job["error"] = result["error"]
        else:
            job["status"] = "completed"
            job["result"] = result

        job["completed_at"] = datetime.now(timezone.utc).isoformat()

    except Exception as exc:
        job["status"] = "failed"
        job["error"] = str(exc)
        job["completed_at"] = datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# POST /process/{upload_id}  — trigger OCR
# ---------------------------------------------------------------------------
@app.post("/process/{upload_id}")
def process_upload(upload_id: str) -> Dict[str, Any]:
    """
    Start a Surya OCR job for an already-uploaded PDF.
    Returns immediately with a job_id; poll /process/{job_id}/status for progress.
    """
    # Resolve the file path
    record = _uploads.get(upload_id)
    if not record:
        matches = list(UPLOAD_DIR.glob(f"{upload_id}_*"))
        if matches:
            record = {
                "upload_id": upload_id,
                "path": str(matches[0]),
                "filename": matches[0].name.split("_", 1)[-1],
                "status": "uploaded",
            }
            _uploads[upload_id] = record
        else:
            raise HTTPException(status_code=404, detail=f"Upload '{upload_id}' not found")

    pdf_path = record.get("path", "")
    if not pdf_path or not Path(pdf_path).exists():
        raise HTTPException(status_code=404, detail=f"PDF file not found on disk: {pdf_path}")

    job_id = str(uuid.uuid4())
    job: Dict[str, Any] = {
        "job_id": job_id,
        "upload_id": upload_id,
        "filename": record.get("filename", ""),
        "form_type": record.get("form_type", "25"),
        "pdf_path": pdf_path,
        "status": "queued",
        "queued_at": datetime.now(timezone.utc).isoformat(),
    }
    _ocr_jobs[job_id] = job

    # Submit to background thread
    _executor.submit(_run_ocr_job, job_id, pdf_path)

    return {
        "job_id": job_id,
        "upload_id": upload_id,
        "status": "queued",
        "message": "Surya OCR job queued. Poll /process/{job_id}/status for progress.",
    }


# ---------------------------------------------------------------------------
# GET /process/{job_id}/status  — poll OCR job
# ---------------------------------------------------------------------------
@app.get("/process/{job_id}/status")
def process_status(job_id: str) -> Dict[str, Any]:
    """Return current status and (when completed) extracted OCR results."""
    job = _ocr_jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"OCR job '{job_id}' not found")

    # Return full job record (includes result when status == completed)
    return job


# ---------------------------------------------------------------------------
# GET /jobs  — admin utility
# ---------------------------------------------------------------------------
@app.get("/jobs")
def list_jobs() -> List[Dict[str, Any]]:
    return [
        {k: v for k, v in job.items() if k != "result"}  # strip large payloads
        for job in _ocr_jobs.values()
    ]


# ---------------------------------------------------------------------------
# POST /extract/{upload_id}  — full ACORD extraction (Surya + Docling + Qwen VL)
# ---------------------------------------------------------------------------
@app.post("/extract/{upload_id}")
async def extract_acord(
    upload_id: str,
    form_type_hint: str = "25",
) -> Dict[str, Any]:
    """
    Full ACORD extraction pipeline for an already-uploaded PDF.

    Step 1 (parallel): Surya OCR + Docling run concurrently.
    Step 2 (serial):   Qwen2-VL receives page images + both outputs.

    Returns: { form_type_detected, pdf_type, extracted_json, full_text, markdown }
    Long-running (30s–5min on GPU).
    """
    record = _uploads.get(upload_id)
    if not record:
        matches = list(UPLOAD_DIR.glob(f"{upload_id}_*"))
        if matches:
            record = {
                "upload_id": upload_id,
                "path": str(matches[0]),
                "filename": matches[0].name.split("_", 1)[-1],
                "status": "uploaded",
            }
            _uploads[upload_id] = record
        else:
            raise HTTPException(status_code=404, detail=f"Upload '{upload_id}' not found")

    pdf_path = record.get("path", "")
    if not pdf_path or not Path(pdf_path).exists():
        raise HTTPException(status_code=404, detail=f"PDF not on disk: {pdf_path}")

    # Normalise form_type: "ACORD_25" → "25", "acord25" → "25", "25" → "25"
    ft = form_type_hint or record.get("form_type", "25")
    if isinstance(ft, str):
        ftl = ft.lower()
        if ftl.startswith("acord_"):
            ft = ft[6:]
        elif ftl.startswith("acord"):
            ft = ft[5:]

    import asyncio
    loop = asyncio.get_running_loop()

    from extractor import run_full_extraction

    result = await loop.run_in_executor(_executor, run_full_extraction, pdf_path, ft)

    if "error" in result:
        raise HTTPException(status_code=500, detail=result["error"])

    return result


# ---------------------------------------------------------------------------
# POST /generate  — text generation using the loaded Qwen2-VL model
# Used by the backend's NL summary service (RUNPOD_GENERATE_URL).
# ---------------------------------------------------------------------------
@app.post("/generate")
async def generate_text(body: Dict[str, Any] = Body(...)) -> Dict[str, Any]:
    """
    Lightweight text generation endpoint backed by the already-loaded Qwen2-VL model.
    Accepts: { prompt, max_new_tokens, temperature, raw }
    Returns: { text }
    """
    import asyncio

    prompt: str = body.get("prompt", "")
    max_new_tokens: int = int(body.get("max_new_tokens", 2048))
    temperature: float = float(body.get("temperature", 0.3))

    if not prompt.strip():
        raise HTTPException(status_code=400, detail="prompt is required")

    def _infer() -> str:
        import extractor as _ext
        import torch

        # _load_qwen() sets extractor._qwen_model / _qwen_processor as module globals.
        # Access them through the module after loading so we always get the live reference,
        # not a None snapshot captured before the model was loaded.
        _ext._load_qwen()
        model     = _ext._qwen_model
        processor = _ext._qwen_processor

        messages = [{"role": "user", "content": [{"type": "text", "text": prompt}]}]
        text_input = processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        inputs = processor(
            text=[text_input],
            padding=True,
            return_tensors="pt",
        ).to(model.device)

        with torch.no_grad():
            generated_ids = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                do_sample=temperature > 0,
            )

        trimmed = [out[len(inp):] for inp, out in zip(inputs.input_ids, generated_ids)]
        return processor.batch_decode(
            trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0]

    loop = asyncio.get_running_loop()
    text = await loop.run_in_executor(_executor, _infer)
    return {"text": text}


# ---------------------------------------------------------------------------
# Training samples — persist across pod restarts via JSONL on disk
# ---------------------------------------------------------------------------

def _pdf_path_for_upload(upload_id: str) -> Optional[str]:
    record = _uploads.get(upload_id)
    if record:
        return record.get("path")
    matches = list(UPLOAD_DIR.glob(f"{upload_id}_*"))
    return str(matches[0]) if matches else None


def _load_training_samples() -> List[Dict[str, Any]]:
    if not TRAINING_SAMPLES_FILE.exists():
        return []
    samples = []
    for line in TRAINING_SAMPLES_FILE.read_text().splitlines():
        line = line.strip()
        if line:
            try:
                samples.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return samples


@app.post("/training-samples")
async def store_training_sample(body: Dict[str, Any] = Body(...)) -> Dict[str, Any]:
    """
    Store one corrected extraction as a fine-tuning sample.
    Called after the user edits and approves the extracted fields.
    Each sample written as a JSONL line so it survives pod restarts.
    """
    upload_id = body.get("upload_id", "")
    pdf_path = _pdf_path_for_upload(upload_id) or ""

    # Normalise form_type so ingest.py never sees "ACORD_25" / "acord25" variants
    raw_ft = str(body.get("form_type") or "25")
    ftl = raw_ft.lower()
    if ftl.startswith("acord_"):
        raw_ft = raw_ft[6:]
    elif ftl.startswith("acord"):
        raw_ft = raw_ft[5:]

    sample: Dict[str, Any] = {
        "sample_id": str(uuid.uuid4()),
        "upload_id": upload_id,
        "pdf_path": pdf_path,
        "form_type": raw_ft,
        "original_fields": body.get("original_fields") or {},
        "corrected_fields": body.get("corrected_fields") or {},
        "raw_text": body.get("raw_text", ""),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "pending",
    }

    with open(TRAINING_SAMPLES_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(sample) + "\n")

    total = len(_load_training_samples())
    return {
        "status": "stored",
        "sample_id": sample["sample_id"],
        "total_samples": total,
    }


@app.get("/training-samples")
def list_training_samples() -> Dict[str, Any]:
    """List all stored training samples (summary for status/count display)."""
    samples = _load_training_samples()
    return {
        "total_samples": len(samples),
        "pending": sum(1 for s in samples if s.get("status") == "pending"),
        "samples": [
            {
                "sample_id": s.get("sample_id"),
                "upload_id": s.get("upload_id"),
                "form_type": s.get("form_type"),
                "created_at": s.get("created_at"),
                "status": s.get("status"),
            }
            for s in samples
        ],
    }


@app.post("/finetune/start")
async def start_finetune(body: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
    """
    Convert all pending training samples to chat-format, snapshot them to
    a versioned JSONL, then launch run_cycle() in a background thread.

    Returns immediately with job_id for polling via GET /finetune/jobs/{job_id}.
    """
    import asyncio
    from fine_tuning.continuous_learning.ingest import build_training_sample_from_correction
    from fine_tuning.continuous_learning.version_store import append_training_sample
    from fine_tuning.job_runner import launch_cycle_background

    samples = [s for s in _load_training_samples() if s.get("status") == "pending"]
    if not samples:
        return {
            "status": "no_samples",
            "message": "No pending training samples found.",
            "total_samples": 0,
        }

    ft_config_path = os.getenv(
        "FINE_TUNING_CONFIG_PATH",
        str(Path(__file__).parent / "fine_tuning" / "config.yaml"),
    )

    # ── Load continuous-learning config ───────────────────────────────────────
    try:
        from fine_tuning.config_schema import load_and_validate_config
        ft_cfg = load_and_validate_config(ft_config_path)
    except Exception as e:
        return {"status": "error", "message": f"Could not load fine-tuning config: {e}"}

    cl_cfg       = ft_cfg.get("continuous_learning", {})
    feedback_dir = Path(cl_cfg.get("feedback_datasets_dir",
                                   "/workspace/fine_tuning/datasets/feedback_learning"))
    threshold    = int(cl_cfg.get("retrain_threshold", 25))

    # ── Build chat-format samples and append to version store ─────────────────
    snapshot_path: Optional[str] = None
    ingested = 0
    ingested_ids: set = set()   # only successfully processed samples get marked "used"
    for sample in samples:
        try:
            chat_row = build_training_sample_from_correction(
                run_row=sample,
                corrected_json=sample.get("corrected_fields") or {},
            )
            outcome = append_training_sample(
                root=feedback_dir,
                row=chat_row,
                retrain_threshold=threshold,
            )
            ingested += 1
            ingested_ids.add(sample.get("sample_id"))
            if outcome.version_snapshot_path:
                snapshot_path = outcome.version_snapshot_path
        except Exception as exc:
            print(f"[finetune/start] skipping sample {sample.get('sample_id')} (stays pending for retry): {exc}")

    if not snapshot_path:
        # Force a snapshot from whatever is pending now (manual trigger bypasses threshold)
        import json as _json
        pending_file = feedback_dir / "pending.jsonl"
        if pending_file.exists() and pending_file.stat().st_size > 0:
            from fine_tuning.continuous_learning.version_store import (
                _load_manifest, _save_manifest, _version_path, _pending_path,
            )
            manifest = _load_manifest(feedback_dir)
            version  = int(manifest.get("next_version", 1))
            vp = _version_path(feedback_dir, version)
            vp.parent.mkdir(parents=True, exist_ok=True)
            vp.write_bytes(pending_file.read_bytes())
            pending_file.write_text("", encoding="utf-8")
            manifest["pending_count"]  = 0
            manifest["next_version"]   = version + 1
            manifest.setdefault("snapshots", []).append({
                "version":    version,
                "path":       str(vp),
                "rows":       ingested,
                "created_at": datetime.now(timezone.utc).isoformat(),
            })
            _save_manifest(feedback_dir, manifest)
            snapshot_path = str(vp)
        else:
            return {
                "status": "no_data",
                "message": "Samples ingested but no training data in pending store.",
                "ingested": ingested,
            }

    # ── Mark successfully ingested samples as "used" — skipped ones stay pending ──
    used_ids = ingested_ids
    all_samples = _load_training_samples()
    used_at = datetime.now(timezone.utc).isoformat()
    updated_samples = []
    for s in all_samples:
        if s.get("sample_id") in used_ids:
            s["status"] = "used"
            s["used_at"] = used_at
        updated_samples.append(s)
    TRAINING_SAMPLES_FILE.write_text(
        "\n".join(json.dumps(s) for s in updated_samples) + "\n",
        encoding="utf-8",
    )

    # ── Launch cycle in background thread ─────────────────────────────────────
    job_id = str(uuid.uuid4())
    launch_cycle_background(
        config_path=ft_config_path,
        new_data_path=snapshot_path,
        job_id=job_id,
    )

    return {
        "status": "queued",
        "job_id": job_id,
        "message": (
            f"Fine-tuning started with {ingested} sample(s). "
            f"Poll GET /finetune/jobs/{job_id} for progress."
        ),
        "total_samples": ingested,
        "snapshot_path": snapshot_path,
    }


@app.get("/finetune/jobs/{job_id}")
def finetune_job_status(job_id: str) -> Dict[str, Any]:
    """
    Poll the status of a fine-tuning job launched via POST /finetune/start.

    Phases: starting → loading_config → building_dataset → resolving_base_model
            → training → evaluating → gate_checked → merging → promoting → done

    Status values: running | completed | gate_failed | failed
    """
    from fine_tuning.job_runner import get_job_status
    job = get_job_status(job_id)
    if job:
        return job

    # Fallback: check version registry for historical jobs
    try:
        from fine_tuning.registry.version_registry import VersionRegistry
        registry_path = os.getenv("VERSION_REGISTRY_PATH", "/workspace/fine_tuning/registry/version_registry.json")
        reg = VersionRegistry(registry_path)
        versions = reg.list_versions()
        for v in versions:
            if v.get("job_id") == job_id:
                return {
                    "job_id":      job_id,
                    "status":      "completed" if v.get("status") == "promoted" else v.get("status"),
                    "phase":       "done",
                    "version":     v.get("version"),
                    "eval_scores": v.get("eval_scores"),
                    "finished_at": v.get("promoted_at"),
                }
    except Exception:
        pass

    raise HTTPException(status_code=404, detail=f"Fine-tuning job '{job_id}' not found")


@app.get("/finetune/jobs")
def list_finetune_jobs() -> Dict[str, Any]:
    """List all fine-tuning jobs tracked in this server session."""
    from fine_tuning.job_runner import _jobs
    return {
        "total": len(_jobs),
        "jobs": [
            {
                "job_id":      jid,
                "status":      j.get("status"),
                "phase":       j.get("phase"),
                "version":     j.get("version"),
                "started_at":  j.get("started_at"),
                "finished_at": j.get("finished_at"),
            }
            for jid, j in _jobs.items()
        ],
    }


@app.get("/registry/versions")
def list_registry_versions() -> Dict[str, Any]:
    """Return the full version registry (SLM version history)."""
    registry_path = os.getenv(
        "VERSION_REGISTRY_PATH",
        "/workspace/fine_tuning/registry/version_registry.json",
    )
    try:
        from fine_tuning.registry.version_registry import VersionRegistry
        reg = VersionRegistry(registry_path)
        return {
            "current_version": reg.get_current_version(),
            "current_base":    reg.get_current_base(),
            "versions":        reg.list_versions(),
        }
    except Exception as exc:
        return {"error": str(exc), "versions": []}


# ---------------------------------------------------------------------------
# Federated Learning — FedAvg aggregation across all SeaweedFS weight versions
# ---------------------------------------------------------------------------

_fed_jobs: Dict[str, Dict[str, Any]] = {}
_fed_jobs_lock = threading.Lock()


def _set_fed_job(job_id: str, data: Dict[str, Any]) -> None:
    with _fed_jobs_lock:
        _fed_jobs[job_id] = data


def _update_fed_job(job_id: str, phase: str, **kwargs: Any) -> None:
    with _fed_jobs_lock:
        if job_id in _fed_jobs:
            _fed_jobs[job_id]["phase"] = phase
            _fed_jobs[job_id].update(kwargs)


def _fedavg_safetensors(model_dirs: List[str], output_dir: str) -> None:
    """
    Average safetensors weights across model_dirs → output_dir (FedAvg with equal weights).
    Falls back to copying the latest model if safetensors/torch are unavailable.
    """
    import shutil as _shutil
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)

    if len(model_dirs) == 1:
        _shutil.copytree(model_dirs[0], output_dir, dirs_exist_ok=True)
        print("[fedavg] Single model — copied without averaging.")
        return

    try:
        from safetensors import safe_open
        from safetensors.torch import save_file
        import torch
    except ImportError as _ie:
        raise ImportError(
            "safetensors and torch are required for FedAvg aggregation. "
            f"Install them with: pip install safetensors torch\nOriginal error: {_ie}"
        ) from _ie

    last_dir = Path(model_dirs[-1])
    # Copy all non-weight files (config.json, tokenizer, etc.) from the latest model
    for f in last_dir.iterdir():
        if f.suffix == ".safetensors":
            continue
        dest = output / f.name
        if f.is_dir():
            _shutil.copytree(str(f), str(dest), dirs_exist_ok=True)
        else:
            _shutil.copy2(str(f), str(dest))

    shards = sorted(last_dir.glob("*.safetensors"))
    if not shards:
        _shutil.copytree(model_dirs[-1], output_dir, dirs_exist_ok=True)
        return

    print(f"[fedavg] Averaging {len(model_dirs)} models across {len(shards)} shard(s)…")
    for shard in shards:
        all_tensors: Dict[str, list] = {}
        for mdir in model_dirs:
            shard_path = Path(mdir) / shard.name
            if not shard_path.exists():
                continue
            with safe_open(str(shard_path), framework="pt") as f:
                for key in f.keys():
                    all_tensors.setdefault(key, []).append(f.get_tensor(key))
        averaged = {k: torch.stack(vs).mean(dim=0) for k, vs in all_tensors.items() if vs}
        save_file(averaged, str(output / shard.name))
        print(f"[fedavg]   Averaged shard: {shard.name}")

    print(f"[fedavg] Done — aggregated model written to {output_dir}")


def _run_federated_job(job_id: str) -> None:
    """Background thread: download all SeaweedFS versions, FedAvg, upload result."""
    import shutil as _shutil
    import tempfile

    try:
        from fine_tuning.seaweedfs_client import SeaweedFSClient
        seaweed = SeaweedFSClient()

        # ── 1. Discover all available fine-tuned versions ────────────────────
        _update_fed_job(job_id, "discovering_versions")
        latest = seaweed.get_latest_finetuned_version()
        if latest is None:
            raise RuntimeError("No fine-tuned weights found in SeaweedFS. Run Local Training first.")

        versions_available: List[int] = []
        try:
            client = seaweed._boto_client()
            for v in range(max(1, latest - 9), latest + 1):   # check up to last 10 versions
                resp = client.list_objects_v2(
                    Bucket=seaweed._bucket, Prefix=f"finetuned/v{v}/", MaxKeys=1
                )
                if resp.get("Contents"):
                    versions_available.append(v)
        except Exception as exc:
            print(f"[federated] Version discovery error (using latest only): {exc}")
            versions_available = [latest]

        if not versions_available:
            versions_available = [latest]

        _update_fed_job(job_id, "downloading_weights", versions_aggregated=versions_available)
        print(f"[federated] Aggregating versions: {versions_available}")

        # ── 2. Download all versions (skip any that fail — partial FedAvg is better than none) ──
        tmp_dir = Path(tempfile.mkdtemp(prefix="fedavg_"))
        try:
            model_dirs: List[str] = []
            downloaded_versions: List[int] = []
            skipped_versions: List[int] = []
            for v in versions_available:
                local_dir = str(tmp_dir / f"v{v}")
                try:
                    seaweed.download_finetuned_model(v, local_dir)
                    model_dirs.append(local_dir)
                    downloaded_versions.append(v)
                    print(f"[federated] v{v} downloaded ✓")
                except Exception as dl_exc:
                    print(f"[federated] WARNING: Skipping v{v} — download failed: {dl_exc}")
                    skipped_versions.append(v)

            if not model_dirs:
                raise RuntimeError(
                    f"All {len(versions_available)} version(s) failed to download from SeaweedFS. "
                    f"Check that {seaweed._endpoint} is reachable from the pod. "
                    f"Versions attempted: {versions_available}"
                )

            if skipped_versions:
                print(
                    f"[federated] Proceeding with {len(model_dirs)} version(s) "
                    f"(skipped {skipped_versions} due to download errors)"
                )

            # ── 3. FedAvg aggregation ─────────────────────────────────────────
            _update_fed_job(job_id, "aggregating")
            agg_dir = str(tmp_dir / "aggregated")
            _fedavg_safetensors(model_dirs, agg_dir)

            # B7: verify aggregated model is valid before uploading
            _agg_path = Path(agg_dir)
            if not (_agg_path / "config.json").exists():
                raise RuntimeError(
                    f"FedAvg output at {agg_dir} is missing config.json — "
                    "aggregation may have failed silently. Aborting upload."
                )

            # ── 4. Quantize aggregated model → GGUF ──────────────────────────
            _update_fed_job(job_id, "quantizing")
            gguf_dir = str(tmp_dir / "gguf")
            try:
                from fine_tuning.quantization.quantizer import run_quantization
                quant_results = run_quantization(agg_dir, gguf_dir, latest + 1)
                print(f"[federated] Quantization produced {len(quant_results)} GGUF(s)")
            except Exception as exc:
                print(f"[federated] Quantization failed (non-fatal): {exc}")
                quant_results = {}

            # ── 5. Upload aggregated model + GGUFs as new version ─────────────
            _update_fed_job(job_id, "uploading")
            new_version = latest + 1
            seaweed.upload_hf_model(agg_dir, new_version)
            gguf_s3_keys: List[str] = []
            if quant_results:
                try:
                    gguf_s3_keys = seaweed.upload_quantized(gguf_dir, new_version)
                    print(f"[federated] GGUF(s) uploaded for v{new_version}")
                except Exception as exc:
                    print(f"[federated] GGUF upload failed (non-fatal): {exc}")

            # Register GGUFs in Supabase adapter_registry so Electron devices
            # can discover and download the globally aggregated model.
            if gguf_s3_keys:
                try:
                    from fine_tuning.training_orchestrator import _register_gguf_in_supabase
                    _register_gguf_in_supabase(gguf_s3_keys, new_version, gguf_dir)
                except Exception as exc:
                    print(f"[federated] adapter_registry registration failed (non-fatal): {exc}")

            # ── Done ──────────────────────────────────────────────────────────
            _set_fed_job(job_id, {
                **_fed_jobs.get(job_id, {}),
                "status": "completed",
                "phase": "done",
                "finished_at": datetime.now(timezone.utc).isoformat(),
                "version": new_version,
                "versions_aggregated": downloaded_versions,
                "versions_skipped": skipped_versions,
            })
            print(f"[federated] Aggregation complete — new version v{new_version} in SeaweedFS.")
        finally:
            _shutil.rmtree(tmp_dir, ignore_errors=True)

    except Exception as exc:
        import traceback
        print(f"[federated] Job {job_id} FAILED: {exc}\n{traceback.format_exc()[-1000:]}")
        with _fed_jobs_lock:
            if job_id in _fed_jobs:
                _fed_jobs[job_id].update({
                    "status": "failed",
                    "phase": "done",
                    "finished_at": datetime.now(timezone.utc).isoformat(),
                    "error": str(exc),
                })


def _run_share_job(job_id: str, pending_entries: List[tuple]) -> None:
    """
    Background thread: upload all pending weight versions to SeaweedFS.
    pending_entries: list of (file_path: Path, pending: Dict) tuples, one per training run.
    Processes sequentially. Deletes each file after successful upload.
    Stops on first failure (undeleted file stays for retry).
    """
    def _upd(phase: str, **kw: Any) -> None:
        with _share_jobs_lock:
            if job_id in _share_jobs:
                _share_jobs[job_id]["phase"] = phase
                _share_jobs[job_id].update(kw)

    try:
        from fine_tuning.training_orchestrator import promote_adapter

        uploaded_versions: List[int] = []
        for file_path, pending in pending_entries:
            version = pending.get("version", "?")
            _upd(f"uploading_v{version}")
            print(f"[share-gradients] Uploading v{version} ({file_path.name})…")

            # B4: validate paths exist before calling promote_adapter
            merged_model_path = pending.get("merged_model_path", "")
            adapter_path = pending.get("adapter_path", "")
            if not merged_model_path or not Path(merged_model_path).exists():
                raise RuntimeError(
                    f"v{version}: merged_model_path missing or not on disk: '{merged_model_path}'. "
                    "The pod may have restarted and lost the merged weights."
                )
            if not adapter_path or not Path(adapter_path).exists():
                raise RuntimeError(
                    f"v{version}: adapter_path missing or not on disk: '{adapter_path}'."
                )

            promote_adapter(
                adapter_id=pending["job_id"],
                registry_path=pending["registry_path"],
                version=pending["version"],
                merged_model_path=pending["merged_model_path"],
                adapter_path=pending["adapter_path"],
                eval_scores=pending.get("eval_scores", {}),
                training_meta=pending.get("training_meta", {}),
                base_model=pending.get("base_model", ""),
            )
            # Delete pending-share manifest only after confirmed upload success
            file_path.unlink(missing_ok=True)

            # Delete local weight directories — they are now safely on SeaweedFS
            import shutil as _shutil
            _merged = Path(merged_model_path)
            if _merged.exists():
                _shutil.rmtree(_merged, ignore_errors=True)
                print(f"[share-gradients] Deleted local merged model: {_merged}")
            # GGUF dir sits next to the merged dir as {version}-gguf/
            _gguf_dir = _merged.parent / f"{version}-gguf"
            if _gguf_dir.exists():
                _shutil.rmtree(_gguf_dir, ignore_errors=True)
                print(f"[share-gradients] Deleted local GGUF dir: {_gguf_dir}")
            _adapter = Path(adapter_path)
            if _adapter.exists():
                _shutil.rmtree(_adapter, ignore_errors=True)
                print(f"[share-gradients] Deleted local adapter: {_adapter}")

            uploaded_versions.append(version)
            print(f"[share-gradients] v{version} uploaded, local weights cleared.")

        with _share_jobs_lock:
            _share_jobs[job_id].update({
                "status":            "completed",
                "phase":             "done",
                "finished_at":       datetime.now(timezone.utc).isoformat(),
                "uploaded_versions": uploaded_versions,
                "version":           uploaded_versions[-1] if uploaded_versions else None,
            })
        print(f"[share-gradients] All done — uploaded: {uploaded_versions}")

    except Exception as exc:
        import traceback
        print(f"[share-gradients] FAILED: {exc}\n{traceback.format_exc()[-1000:]}")
        with _share_jobs_lock:
            if job_id in _share_jobs:
                _share_jobs[job_id].update({
                    "status":      "failed",
                    "phase":       "done",
                    "finished_at": datetime.now(timezone.utc).isoformat(),
                    "error":       str(exc),
                })


@app.post("/share-gradients")
async def share_gradients_endpoint(body: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
    """
    Upload ALL locally-merged fine-tuned weight versions to SeaweedFS.
    Must be called manually by the user after Local Training completes.
    Reads every *.json file from /workspace/fine_tuning/pending_shares/ written by job_runner.
    Each version gets its own file — none are overwritten, all are uploaded.
    """
    import asyncio

    if not PENDING_SHARE_DIR.exists():
        return {
            "status":  "no_pending",
            "message": "No weights ready to share. Complete Local Training first.",
        }

    def _version_key(p: Path) -> int:
        try:
            return int(p.stem.lstrip("v"))
        except ValueError:
            return 0

    pending_files = sorted(PENDING_SHARE_DIR.glob("*.json"), key=_version_key)
    if not pending_files:
        return {
            "status":  "no_pending",
            "message": "No weights ready to share. Complete Local Training first.",
        }

    pending_entries: List[tuple] = []
    for fp in pending_files:
        try:
            pending_entries.append((fp, json.loads(fp.read_text(encoding="utf-8"))))
        except Exception as exc:
            print(f"[share-gradients] Skipping unreadable file {fp.name}: {exc}")

    if not pending_entries:
        return {"status": "error", "message": "Pending share files exist but could not be read."}

    versions = [p.get("version") for _, p in pending_entries]
    job_id = str(uuid.uuid4())
    with _share_jobs_lock:
        _share_jobs[job_id] = {
            "job_id":            job_id,
            "status":            "running",
            "phase":             "starting",
            "started_at":        datetime.now(timezone.utc).isoformat(),
            "finished_at":       None,
            "pending_versions":  versions,
            "uploaded_versions": [],
            "error":             None,
        }

    loop = asyncio.get_running_loop()
    loop.run_in_executor(_executor, _run_share_job, job_id, pending_entries)

    return {
        "status":           "queued",
        "job_id":           job_id,
        "pending_versions": versions,
        "message": (
            f"Uploading {len(pending_entries)} version(s) {versions} to SeaweedFS. "
            f"Poll GET /share-gradients/jobs/{job_id}."
        ),
    }


@app.get("/share-gradients/status")
def share_gradients_status() -> Dict[str, Any]:
    """Return whether there are pending weights ready to share."""
    if not PENDING_SHARE_DIR.exists():
        return {"has_pending": False, "pending_count": 0, "pending_versions": []}

    def _version_key(p: Path) -> int:
        try:
            return int(p.stem.lstrip("v"))
        except ValueError:
            return 0

    pending_files = sorted(PENDING_SHARE_DIR.glob("*.json"), key=_version_key)
    pending_versions: List[int] = []
    for fp in pending_files:
        try:
            data = json.loads(fp.read_text(encoding="utf-8"))
            v = data.get("version")
            if v is not None:
                pending_versions.append(v)
        except Exception:
            pass

    return {
        "has_pending":      len(pending_files) > 0,
        "pending_count":    len(pending_files),
        "pending_versions": pending_versions,
    }


@app.get("/share-gradients/jobs/{job_id}")
def get_share_gradients_job(job_id: str) -> Dict[str, Any]:
    """Poll the status of a share-gradients job."""
    with _share_jobs_lock:
        job = _share_jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Share-gradients job '{job_id}' not found")
    return job


@app.post("/federated/start")
async def start_federated(body: Dict[str, Any] = Body(default={})) -> Dict[str, Any]:
    """
    Collect all fine-tuned weight versions from SeaweedFS and run FedAvg aggregation.
    Returns immediately with job_id; poll GET /federated/jobs/{job_id} for status.
    """
    import asyncio
    from fine_tuning.seaweedfs_client import SeaweedFSClient

    seaweed = SeaweedFSClient()

    # ── Pre-flight: verify SeaweedFS is reachable before queuing the job ────────
    # This gives the user an immediate clear error instead of a background job
    # that silently fails minutes later with RetriesExceededError.
    if not seaweed._configured:
        return {
            "status": "error",
            "message": "SEAWEEDFS_ENDPOINT is not configured on the pod.",
        }
    try:
        import boto3
        from botocore.config import Config as _BotoConfig
        _probe = boto3.client(
            "s3",
            endpoint_url=seaweed._endpoint,
            aws_access_key_id=seaweed._access_key,
            aws_secret_access_key=seaweed._secret_key,
            config=_BotoConfig(connect_timeout=8, read_timeout=8, retries={"max_attempts": 1}),
        )
        _probe.list_objects_v2(Bucket=seaweed._bucket, Prefix="finetuned/", MaxKeys=1)
    except Exception as _conn_exc:
        return {
            "status": "seaweedfs_unreachable",
            "message": (
                f"Cannot reach SeaweedFS at {seaweed._endpoint} (bucket={seaweed._bucket}). "
                f"Error: {_conn_exc}. "
                f"Verify the pod can reach SeaweedFS: run  curl -m 8 {seaweed._endpoint}  "
                f"from the pod terminal."
            ),
        }

    latest = seaweed.get_latest_finetuned_version()
    if latest is None:
        return {
            "status": "no_weights",
            "message": "No fine-tuned weights found in SeaweedFS. Complete Local Training first.",
            "versions_found": 0,
        }

    job_id = str(uuid.uuid4())
    _set_fed_job(job_id, {
        "job_id": job_id,
        "status": "running",
        "phase": "starting",
        "started_at": datetime.now(timezone.utc).isoformat(),
        "finished_at": None,
        "error": None,
        "version": None,
        "versions_aggregated": [],
    })

    loop = asyncio.get_running_loop()
    loop.run_in_executor(_executor, _run_federated_job, job_id)

    return {
        "status": "queued",
        "job_id": job_id,
        "message": f"Federated aggregation started. Poll GET /federated/jobs/{job_id} for progress.",
    }


@app.get("/federated/jobs/{job_id}")
def get_federated_job(job_id: str) -> Dict[str, Any]:
    """Return current status of a federated aggregation job."""
    with _fed_jobs_lock:
        job = _fed_jobs.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Federated job '{job_id}' not found")
    return job


# ---------------------------------------------------------------------------
# Entrypoint
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=PORT, log_level="info")
