"""
Fine-tuning job runner for the Fideon RunPod pod.

run_cycle() is the top-level entry point called by server.py when a user
clicks "Fine-tune" or when the correction threshold is crossed automatically.

Full pipeline (mirrors the ACORD pipeline document STEP 6):

  load_and_validate_config()
      ↓
  check_eval_files()          — pre-flight (non-fatal)
      ↓
  RegistryLock                — prevent concurrent cycles
      ↓
  DatasetBuilder.build()      — new JSONL + replay rows → train.jsonl
      ↓
  resolve_base_model_path()   — SeaweedFS latest → registry → base model
      ↓
  registry.create_pending_entry()
      ↓
  run_training()              — QLoRA SFT → LoRA adapter
      ↓
  run_local_eval()            — field F1/recall on eval examples
      ↓
  run_deepeval()              — optional LLM-judge metrics
      ↓
  ForgettingEvaluator.evaluate()
      ↓
  run_eval_gate()             — promote / block decision
      ↓
  [gate passed]
  AdapterMerger.merge()       — merge adapter → full weights
      ↓
  promote_adapter()           — SeaweedFS upload + registry + model card + alert
      ↓
  registry.promote_version()  — SLM v1.N is now the active model
"""
from __future__ import annotations

import json
import os
import shutil
import threading
import traceback
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


# ── Result dataclass ──────────────────────────────────────────────────────────

@dataclass
class CycleResult:
    status: str                     # "completed" | "failed" | "gate_failed"
    cycle_id: str
    version: Optional[int]
    adapter_path: Optional[str]
    merged_model_path: Optional[str]
    gate_passed: bool
    eval_scores: Dict[str, Any]
    error: Optional[str]
    started_at: str
    finished_at: str


# ── In-memory job store (server.py reads this for status polling) ─────────────

_jobs: Dict[str, Dict[str, Any]] = {}
_jobs_lock = threading.Lock()


def get_job_status(job_id: str) -> Optional[Dict[str, Any]]:
    with _jobs_lock:
        return _jobs.get(job_id)


def _set_job(job_id: str, data: Dict[str, Any]) -> None:
    with _jobs_lock:
        _jobs[job_id] = data


# ── Helpers ───────────────────────────────────────────────────────────────────

def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


_MIN_FREE_DISK_GB = float(os.getenv("MIN_FREE_DISK_GB", "15"))


def _free_disk_gb(path: str = "/workspace") -> float:
    try:
        stat = shutil.disk_usage(path)
        return stat.free / (1024 ** 3)
    except Exception:
        return 999.0


def _cleanup_old_runs(runs_dir: Path, active_model_path: Optional[str], keep_last: int = 1) -> None:
    """
    Delete old merged model directories to free disk space.
    Keeps the `keep_last` most-recent merged dirs and never deletes the active_model_path.
    """
    merged_dirs = sorted(
        [d for d in runs_dir.iterdir() if d.is_dir() and d.name.endswith("-merged")],
        key=lambda d: d.stat().st_mtime,
    )
    to_delete = merged_dirs[: max(0, len(merged_dirs) - keep_last)]
    for d in to_delete:
        if active_model_path and str(d) == active_model_path.rstrip("/"):
            continue  # never delete the currently active model
        try:
            shutil.rmtree(d)
            print(f"[job_runner] Cleaned up old run: {d}")
        except Exception as exc:
            print(f"[job_runner] Warning: could not clean up {d}: {exc}")


def _check_eval_files(config: Dict[str, Any]) -> None:
    """Warn (non-fatal) if eval JSON files referenced in config are missing."""
    eval_cfg = config.get("evaluation", {})
    for key in ("seen_questions_path", "paraphrased_questions_path", "out_of_scope_questions_path"):
        p = eval_cfg.get(key)
        if p and not Path(p).exists():
            print(f"[job_runner] Warning: eval file not found: {p}")


def _load_eval_examples_from_config(config: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Load eval examples from the paths in config.evaluation.
    Returns a list of {"user_content": str, "expected_fields": dict}.
    """
    eval_cfg = config.get("evaluation", {})
    examples: List[Dict[str, Any]] = []

    for path_key in ("seen_questions_path", "paraphrased_questions_path"):
        p = eval_cfg.get(path_key)
        if not p or not Path(p).exists():
            continue
        try:
            raw = json.loads(Path(p).read_text(encoding="utf-8"))
            items = raw if isinstance(raw, list) else []
            for item in items:
                uc = item.get("user_content") or item.get("input") or item.get("question") or ""
                ef = item.get("expected_fields") or item.get("output") or {}
                if isinstance(ef, str):
                    try:
                        ef = json.loads(ef)
                    except Exception:
                        ef = {}
                examples.append({"user_content": uc, "expected_fields": ef})
        except Exception as exc:
            print(f"[job_runner] Warning: could not load eval file {p}: {exc}")

    return examples


def _evict_old_seaweedfs_caches(cache_root: Path, keep_version: int) -> None:
    """Delete all finetuned/v{N}/ cache dirs except the one we're about to use."""
    if not cache_root.exists():
        return
    for d in cache_root.iterdir():
        if not d.is_dir() or not d.name.startswith("v"):
            continue
        try:
            v = int(d.name[1:])
        except ValueError:
            continue
        if v != keep_version:
            shutil.rmtree(d, ignore_errors=True)
            print(f"[job_runner] Evicted old SeaweedFS cache: {d}")


def _resolve_base_model(config: Dict[str, Any], registry_path: str, runs_dir: Optional[Path] = None) -> str:
    """
    Return the base model path to train from, in priority order:

      1. Latest fine-tuned model on SeaweedFS (finetuned/v{N}/)
         — downloaded only when sufficient free disk space exists
      2. Current promoted model path from local registry (already on disk)
      3. config.base_model (original Qwen2-VL-7B)

    Cleans up old merged runs before attempting SeaweedFS download to free space.
    """
    from fine_tuning.seaweedfs_client import SeaweedFSClient
    from fine_tuning.registry.version_registry import VersionRegistry

    registry = VersionRegistry(registry_path)
    seaweed = SeaweedFSClient()

    # ── Pre-flight: clean up old merged runs to reclaim disk ─────────────────
    if runs_dir and runs_dir.exists():
        active = registry.get_current_base()
        _cleanup_old_runs(runs_dir, active_model_path=active, keep_last=1)
        free_gb = _free_disk_gb()
        print(f"[job_runner] Free disk after cleanup: {free_gb:.1f} GB")

    # ── 1. SeaweedFS: latest fine-tuned version ───────────────────────────────
    seaweed_version = seaweed.get_latest_finetuned_version()
    if seaweed_version is None:
        print("[job_runner] WARNING: SeaweedFS returned no version (unreachable or no uploads yet). "
              "Falling back to local registry or base model.")
    if seaweed_version is not None:
        cache_dir = f"/workspace/fine_tuning/models/finetuned/v{seaweed_version}"
        cache_path = Path(cache_dir)
        # Validate cached model is complete — a partial upload/download with missing shards
        # causes OSError at training time. Check config.json AND all shards from the index.
        def _cache_is_complete(p: Path) -> bool:
            if not p.exists() or not (p / "config.json").exists():
                return False
            index_file = p / "model.safetensors.index.json"
            if index_file.exists():
                try:
                    import json as _json
                    idx = _json.loads(index_file.read_text())
                    expected = set((idx.get("weight_map") or {}).values())
                    existing = {f.name for f in p.glob("*.safetensors")}
                    if expected and not expected.issubset(existing):
                        missing = expected - existing
                        print(f"[job_runner] Cache v{seaweed_version} missing shards: {missing}")
                        return False
                except Exception:
                    pass
            return any(f.suffix == ".safetensors" for f in p.iterdir())

        if _cache_is_complete(cache_path):
            print(f"[job_runner] Using cached SeaweedFS model v{seaweed_version}: {cache_dir}")
            _evict_old_seaweedfs_caches(cache_path.parent, keep_version=seaweed_version)
            return cache_dir
        if cache_path.exists():
            print(f"[job_runner] Cached model v{seaweed_version} is incomplete — deleting and re-downloading …")
            shutil.rmtree(cache_path, ignore_errors=True)
        free_gb = _free_disk_gb()
        if free_gb < _MIN_FREE_DISK_GB:
            print(
                f"[job_runner] Skipping SeaweedFS download — only {free_gb:.1f} GB free "
                f"(need ≥{_MIN_FREE_DISK_GB} GB). Falling back to local model."
            )
        else:
            print(
                f"[job_runner] Downloading fine-tuned model v{seaweed_version} "
                f"from SeaweedFS → {cache_dir} …"
            )
            try:
                seaweed.download_finetuned_model(seaweed_version, cache_dir)
                print(f"[job_runner] SeaweedFS model v{seaweed_version} ready at {cache_dir}")
                _evict_old_seaweedfs_caches(cache_path.parent, keep_version=seaweed_version)
                return cache_dir
            except Exception as exc:
                print(f"[job_runner] SeaweedFS download failed (non-fatal): {exc}")
                # Remove partial download to reclaim space
                if cache_path.exists():
                    shutil.rmtree(cache_path, ignore_errors=True)

    # ── 2. Local registry: last promoted path ─────────────────────────────────
    current = registry.get_current_base()
    if current and Path(current).exists():
        print(f"[job_runner] Resuming from local promoted model: {current}")
        return current

    # ── 3. Original base model ────────────────────────────────────────────────
    fallback = config.get("base_model", "/workspace/models/qwen2-vl-7b")
    print(f"[job_runner] Using original base model: {fallback}")
    return fallback


# ── Main orchestrator ─────────────────────────────────────────────────────────

def run_cycle(
    config_path: str,
    new_data_path: str,
    job_id: str,
    registry_lock_timeout_seconds: int = 30,
) -> CycleResult:
    """
    Run one complete continuous-learning cycle.

    Parameters
    ----------
    config_path   : path to fine_tuning/config.yaml on the pod
    new_data_path : path to the JSONL snapshot (from version_store)
    job_id        : unique identifier for this cycle (used in output paths)
    registry_lock_timeout_seconds: max wait for the file-based registry lock

    Returns
    -------
    CycleResult with status, version, paths, gate result, and error info.
    """
    from fine_tuning.config_schema import load_and_validate_config
    from fine_tuning.dataset.dataset_builder import DatasetBuilder, InsufficientDataError
    from fine_tuning.registry.version_registry import VersionRegistry
    from fine_tuning.continuous_learning.version_store import RegistryLock
    from fine_tuning.train import run_training
    from fine_tuning.training.merger import AdapterMerger
    from fine_tuning.evaluation.local_metrics import run_local_eval
    from fine_tuning.evaluation.deepeval_runner import run_deepeval
    from fine_tuning.evaluation.forgetting_eval import ForgettingEvaluator
    from fine_tuning.evaluation.eval_gate import run_eval_gate
    # promote_adapter is NOT called here — user must click "Share Gradients" to upload to SeaweedFS

    started_at = _utc_now()
    cycle_id   = str(uuid.uuid4())[:12]

    _set_job(job_id, {
        "job_id":     job_id,
        "cycle_id":   cycle_id,
        "status":     "running",
        "phase":      "starting",
        "started_at": started_at,
        "finished_at": None,
        "error":      None,
        "version":    None,
        "gate_passed": None,
    })

    def _update(phase: str, **kwargs: Any) -> None:
        with _jobs_lock:
            if job_id in _jobs:
                _jobs[job_id]["phase"] = phase
                _jobs[job_id].update(kwargs)

    try:
        # ── 1. Load and validate config ───────────────────────────────────────
        _update("loading_config")
        config = load_and_validate_config(config_path)
        paths_cfg  = config["paths"]
        runs_dir   = Path(paths_cfg["runs_dir"])
        reg_path   = paths_cfg["registry_path"]
        runs_dir.mkdir(parents=True, exist_ok=True)

        _check_eval_files(config)

        # ── 2. Acquire registry lock (prevent concurrent cycles) ───────────────
        feedback_dir = config["continuous_learning"]["feedback_datasets_dir"]
        lock_root    = Path(feedback_dir)

        with RegistryLock(lock_root, timeout_seconds=registry_lock_timeout_seconds):

            # ── 3. Build dataset ──────────────────────────────────────────────
            _update("building_dataset")
            builder = DatasetBuilder(config)
            try:
                build_result = builder.build(
                    new_data_path=new_data_path,
                    cycle_id=cycle_id,
                    min_records=1,
                )
            except InsufficientDataError as e:
                raise RuntimeError(str(e))

            print(
                f"[job_runner] Dataset: {build_result.total_records} rows "
                f"({build_result.new_records} new + {build_result.replay_records} replay, "
                f"{build_result.rejected_records} rejected)"
            )

            # ── 4. Resolve base model ─────────────────────────────────────────
            _update("resolving_base_model")
            base_model = _resolve_base_model(config, reg_path, runs_dir=runs_dir)

            # ── 5. Create pending registry entry ─────────────────────────────
            registry = VersionRegistry(reg_path)
            parent_version = registry.get_current_version()
            replay_fraction = float(config.get("training", {}).get("replay_fraction", 0.30))
            run_output_dir  = runs_dir / f"{cycle_id}-adapter"

            new_version = registry.create_pending_entry(
                cycle_id=cycle_id,
                job_id=job_id,
                parent_version=parent_version,
                replay_fraction=replay_fraction,
                checkpoint_dir=str(run_output_dir),
            )
            _update("pending_registered", version=new_version)

            # ── 6. Train (QLoRA SFT) ──────────────────────────────────────────
            _update("training")
            # H100 SXM 80 GB: inference model (BF16 ~14 GB) + training model (BF16 ~14 GB)
            # + merge peak (~28 GB) totals ~56 GB — well within 80 GB. No VRAM unload needed.
            # Extractions continue serving normally throughout the training window.
            print(f"[job_runner] Starting BF16 LoRA training — version={new_version} …")
            adapter_path = run_training(
                config=config,
                dataset_path=build_result.train_jsonl_path,
                output_dir=str(run_output_dir),
                job_id=job_id,
                base_model=base_model,
            )

            # Read training metrics from adapter manifest written by run_training()
            _train_stats: Dict[str, Any] = {}
            try:
                import json as _json
                _manifest_path = Path(adapter_path) / "adapter_manifest.json"
                if _manifest_path.exists():
                    _m = _json.loads(_manifest_path.read_text(encoding="utf-8"))
                    _train_stats = {
                        "training_loss": _m.get("training_loss"),
                        "num_epochs":    _m.get("num_epochs"),
                    }
            except Exception:
                pass

            # ── 7. Evaluation ─────────────────────────────────────────────────
            _update("evaluating")
            eval_examples = _load_eval_examples_from_config(config)
            if not eval_examples:
                print(
                    "[job_runner] WARNING: No eval examples loaded — gate will trivially pass. "
                    "Add eval files to config.evaluation to enable real quality checks."
                )
            print(f"[job_runner] Running local eval on {len(eval_examples)} examples …")

            local_result     = run_local_eval(adapter_path, config, eval_examples)
            deepeval_result  = run_deepeval(adapter_path, config, eval_examples)

            parent_scores = None
            if parent_version > 0:
                versions = registry.list_versions()
                for v in versions:
                    if v["version"] == parent_version:
                        parent_scores = v.get("eval_scores") or {}
                        break

            forgetting = ForgettingEvaluator(config).evaluate(
                adapter_path=adapter_path,
                parent_eval_examples=eval_examples,
                parent_version_scores=parent_scores,
            )

            gate = run_eval_gate(
                local_result, deepeval_result, parent_scores, config, forgetting
            )
            # Merge training metrics into eval_scores so they are available in the registry and UI
            combined_scores = {**gate.scores, **_train_stats}
            _update("gate_checked", gate_passed=gate.passed, eval_scores=combined_scores)

            print(
                f"[job_runner] Gate: passed={gate.passed}  "
                f"scores={combined_scores}  failures={gate.failures}"
            )

            if not gate.passed:
                registry.mark_failed(new_version, "; ".join(gate.failures))
                finished_at = _utc_now()
                _set_job(job_id, {
                    **_jobs.get(job_id, {}),
                    "status":      "gate_failed",
                    "phase":       "done",
                    "finished_at": finished_at,
                    "gate_passed": False,
                    "error":       "; ".join(gate.failures),
                })
                return CycleResult(
                    status="gate_failed",
                    cycle_id=cycle_id,
                    version=new_version,
                    adapter_path=adapter_path,
                    merged_model_path=None,
                    gate_passed=False,
                    eval_scores=gate.scores,
                    error="; ".join(gate.failures),
                    started_at=started_at,
                    finished_at=finished_at,
                )

            # ── 8. Merge adapter → full weights ───────────────────────────────
            _update("merging")
            merged_dir = str(runs_dir / f"{new_version}-{cycle_id}-merged")
            merger     = AdapterMerger()
            merge_result = merger.merge(
                adapter_path=adapter_path,
                base_model_path=base_model,
                output_path=merged_dir,
                config=config,
                cycle_id=cycle_id,
                version=new_version,
            )

            # ── 8b. Validate merge output before writing pending share ─────────
            _merged_path = Path(merge_result.output_path)
            if not _merged_path.exists() or not (_merged_path / "config.json").exists():
                raise RuntimeError(
                    f"Merge output missing or incomplete at {merge_result.output_path}. "
                    "Cannot write pending share — check AdapterMerger logs above."
                )

            # ── 9. Local-only promote + write pending_shares/v{N}.json ──────────
            # SeaweedFS upload is deferred — user must click "Share Gradients".
            # Each training run gets its own file so multiple runs can accumulate
            # and ALL are uploaded when the user clicks Share Gradients.
            _update("pending_share")
            training_meta = {
                "backend":           "qlora_hf",
                "fingerprint":       build_result.fingerprint,
                "job_id":            job_id,
                "base_model":        base_model,
                "replay_fraction":   replay_fraction,
                "seaweedfs_pending": True,
            }

            # Update local version_registry so _resolve_active_model_path()
            # picks up the merged model on pod restart.
            VersionRegistry(reg_path).promote_version(
                version=new_version,
                merged_model_path=merge_result.output_path,
                adapter_path=adapter_path,
                eval_scores=combined_scores,
                training_meta=training_meta,
            )

            # Each version gets its own pending file — never overwritten.
            _PENDING_SHARE_DIR = Path("/workspace/fine_tuning/pending_shares")
            _PENDING_SHARE_DIR.mkdir(parents=True, exist_ok=True)
            (_PENDING_SHARE_DIR / f"v{new_version}.json").write_text(
                json.dumps({
                    "job_id":            job_id,
                    "registry_path":     reg_path,
                    "version":           new_version,
                    "merged_model_path": merge_result.output_path,
                    "adapter_path":      adapter_path,
                    "eval_scores":       combined_scores,
                    "training_meta":     training_meta,
                    "base_model":        base_model,
                    "created_at":        _utc_now(),
                }, indent=2),
                encoding="utf-8",
            )
            pending_count = len(list(_PENDING_SHARE_DIR.glob("*.json")))
            print(f"[job_runner] Weights v{new_version} ready at {merge_result.output_path}. "
                  f"({pending_count} version(s) pending 'Share Gradients')")

            # Hot-swap inference immediately so next extraction uses fine-tuned weights.
            try:
                import extractor as _ext
                _ext.reload_qwen_model(merge_result.output_path)
                print(f"[job_runner] Extractor hot-swapped to fine-tuned model v{new_version}")
            except Exception as _swap_exc:
                print(f"[job_runner] Model hot-swap warning (non-fatal): {_swap_exc}")

        # ── Done ──────────────────────────────────────────────────────────────
        finished_at = _utc_now()
        _set_job(job_id, {
            **(_jobs.get(job_id) or {}),
            "status":             "completed",
            "phase":              "done",
            "finished_at":        finished_at,
            "gate_passed":        True,
            "version":            new_version,
            "adapter_path":       adapter_path,
            "merged_model_path":  merge_result.output_path,
            "eval_scores":        combined_scores,
        })
        print(f"[job_runner] Cycle complete — SLM v1.{new_version} ready. Click 'Share Gradients' to upload to SeaweedFS.")

        return CycleResult(
            status="completed",
            cycle_id=cycle_id,
            version=new_version,
            adapter_path=adapter_path,
            merged_model_path=merge_result.output_path,
            gate_passed=True,
            eval_scores=gate.scores,
            error=None,
            started_at=started_at,
            finished_at=finished_at,
        )

    except Exception as exc:
        finished_at = _utc_now()
        err_msg = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()[-2000:]}"
        print(f"[job_runner] Cycle FAILED: {err_msg}")
        _set_job(job_id, {
            **(_jobs.get(job_id) or {}),
            "status":      "failed",
            "phase":       "done",
            "finished_at": finished_at,
            "error":       str(exc),
        })
        return CycleResult(
            status="failed",
            cycle_id=cycle_id,
            version=None,
            adapter_path=None,
            merged_model_path=None,
            gate_passed=False,
            eval_scores={},
            error=str(exc),
            started_at=started_at,
            finished_at=finished_at,
        )


# ── Background launcher ───────────────────────────────────────────────────────

def launch_cycle_background(
    config_path: str,
    new_data_path: str,
    job_id: str,
) -> None:
    """Spawn run_cycle() in a daemon thread so server.py can return immediately."""
    t = threading.Thread(
        target=run_cycle,
        args=(config_path, new_data_path, job_id),
        daemon=True,
        name=f"finetune-{job_id[:8]}",
    )
    t.start()
    print(f"[job_runner] Fine-tuning launched in background thread (job_id={job_id})")
