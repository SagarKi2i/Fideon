"""
SeaweedFS (S3-compatible) client for uploading quantized GGUF weights.

Required env vars:
  SEAWEEDFS_ENDPOINT   — e.g. http://seaweedfs-gateway:8333
  SEAWEEDFS_BUCKET     — e.g. fideon-adapters
  SEAWEEDFS_ACCESS_KEY — S3 access key
  SEAWEEDFS_SECRET_KEY — S3 secret key

If SEAWEEDFS_ENDPOINT is not set, upload() logs a warning and returns a
placeholder key so the rest of the pipeline continues.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
from typing import Optional


class SeaweedFSClient:
    def __init__(self) -> None:
        self._endpoint   = os.getenv("SEAWEEDFS_ENDPOINT", "").strip().rstrip("/")
        self._bucket     = os.getenv("SEAWEEDFS_BUCKET", "fideon-adapters").strip()
        self._access_key = os.getenv("SEAWEEDFS_ACCESS_KEY", "").strip()
        self._secret_key = os.getenv("SEAWEEDFS_SECRET_KEY", "").strip()

    def _boto_client(self) -> Any:
        import boto3
        return boto3.client(
            "s3",
            endpoint_url=self._endpoint,
            aws_access_key_id=self._access_key,
            aws_secret_access_key=self._secret_key,
        )

    def upload_gguf(
        self,
        local_path: Path,
        adapter_id: str,
        version: str,
    ) -> str:
        """
        Upload a GGUF file to SeaweedFS.
        Returns the S3 key (adapters/{adapter_id}/{version}/{filename}).
        """
        s3_key = f"adapters/{adapter_id}/{version}/{local_path.name}"

        if not self._endpoint:
            print(
                f"[seaweedfs] SEAWEEDFS_ENDPOINT not configured — "
                f"skipping upload of {local_path.name}"
            )
            return s3_key

        print(f"[seaweedfs] Uploading {local_path} → s3://{self._bucket}/{s3_key} …")
        client = self._boto_client()
        client.upload_file(str(local_path), self._bucket, s3_key)
        print("[seaweedfs] Upload complete.")
        return s3_key

    def get_sha256(self, s3_key: str) -> Optional[str]:
        """
        Compute SHA-256 of the remote object by downloading it to memory.
        Returns None if endpoint is not configured.
        """
        if not self._endpoint:
            return None
        try:
            import io
            client = self._boto_client()
            buf = io.BytesIO()
            client.download_fileobj(self._bucket, s3_key, buf)
            buf.seek(0)
            return hashlib.sha256(buf.read()).hexdigest()
        except Exception as exc:
            print(f"[seaweedfs] SHA-256 check failed: {exc}")
            return None

    def find_gguf(self, adapter_path: str) -> Optional[Path]:
        """Return the first .gguf file found in adapter_path, or None."""
        p = Path(adapter_path)
        gguf_files = list(p.glob("*.gguf"))
        return gguf_files[0] if gguf_files else None


# Avoid NameError in type hints without importing at module level
from typing import Any  # noqa: E402
