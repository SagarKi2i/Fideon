"""
Training orchestrator — top-level promote_adapter() called after run_cycle().

Responsibilities:
  • Upload quantized GGUF to SeaweedFS (if configured)
  • Verify upload integrity (SHA-256)
  • Update version_registry.json with SeaweedFS path
  • Write model card
  • Send promotion alert
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

from fine_tuning.seaweedfs_client import SeaweedFSClient
from fine_tuning.observability.alerting import alerter


def promote_adapter(
    adapter_id: str,
    registry_path: str,
    version: int,
    merged_model_path: str,
    adapter_path: str,
    eval_scores: Dict[str, Any],
    training_meta: Dict[str, Any],
    base_model: str = "",
    actor: str = "pipeline",
    force: bool = False,
) -> Dict[str, Any]:
    """
    Finalise promotion of a merged model version.

    Parameters
    ----------
    adapter_id        : job_id / cycle_id used as the S3 folder name
    registry_path     : path to version_registry.json
    version           : integer version number (e.g. 2 → SLM v1.1)
    merged_model_path : local path to the full merged model directory
    adapter_path      : local path to the LoRA adapter directory
    eval_scores       : metric dict written into registry + model card
    training_meta     : training hyperparams etc.
    base_model        : base model path (for model card)
    actor             : who triggered the promotion (pipeline / admin)
    force             : if True, promote even if gate soft-failed (unused here)

    Returns
    -------
    {"new_status": "promoted", "version": int, "seaweedfs_path": str | None}
    """
    from fine_tuning.registry.version_registry import VersionRegistry
    from fine_tuning.registry.model_card import write_model_card

    registry = VersionRegistry(registry_path)
    seaweed  = SeaweedFSClient()
    seaweedfs_path: Optional[str] = None

    # ── Upload GGUF to SeaweedFS (optional) ──────────────────────────────────
    gguf_file = seaweed.find_gguf(merged_model_path)
    if gguf_file:
        try:
            s3_key = seaweed.upload_gguf(gguf_file, adapter_id, str(version))
            sha256 = seaweed.get_sha256(s3_key)
            registry.update_seaweedfs(adapter_id, s3_key, sha256 or "")
            seaweedfs_path = s3_key
        except Exception as exc:
            print(f"[orchestrator] SeaweedFS upload failed (non-fatal): {exc}")
    else:
        print("[orchestrator] No .gguf found — skipping SeaweedFS upload.")

    # ── Update registry ───────────────────────────────────────────────────────
    registry.promote_version(
        version=version,
        merged_model_path=merged_model_path,
        adapter_path=adapter_path,
        eval_scores=eval_scores,
        training_meta=training_meta,
    )

    # ── Write model card ──────────────────────────────────────────────────────
    write_model_card(
        merged_model_path,
        meta={
            "version":       version,
            "base_model":    base_model,
            "eval_scores":   eval_scores,
            "training_meta": training_meta,
        },
    )

    # ── Alert ─────────────────────────────────────────────────────────────────
    alerter.send_promotion(
        adapter_id=adapter_id,
        version=version,
        status="promoted",
        base_model=base_model or merged_model_path,
        seaweedfs_path=seaweedfs_path,
        eval_scores=eval_scores,
    )

    return {
        "new_status":     "promoted",
        "version":        version,
        "seaweedfs_path": seaweedfs_path,
        "actor":          actor,
    }
