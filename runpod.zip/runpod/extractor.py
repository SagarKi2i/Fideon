"""
Full ACORD extraction pipeline for RunPod.
Pipeline: Surya OCR (text detection + recognition) → Qwen2-VL (field extraction).

Models are loaded lazily and cached for reuse across requests.
"""
from __future__ import annotations

import json
import os
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional

# ── Surya OCR singletons ──────────────────────────────────────────────────────
_surya_lock = threading.Lock()
_det_model = None
_det_processor = None
_rec_model = None
_rec_processor = None
_surya_loaded = False

# ── Qwen2-VL singletons ───────────────────────────────────────────────────────
_qwen_lock = threading.Lock()
_qwen_model = None
_qwen_processor = None
_qwen_loaded = False

QWEN_MODEL_ID = os.getenv("QWEN_MODEL_ID", "Qwen/Qwen2-VL-7B-Instruct")


# ── Model loaders ─────────────────────────────────────────────────────────────

def _load_surya() -> None:
    global _det_model, _det_processor, _rec_model, _rec_processor, _surya_loaded
    with _surya_lock:
        if _surya_loaded:
            return

        # transformers >=4.50 calls SuryaOCRConfig() with no args in to_diff_dict(),
        # but surya 0.6.x requires "encoder" in kwargs. Setting this flag skips that call.
        from surya.model.recognition.config import SuryaOCRConfig
        SuryaOCRConfig.has_no_defaults_at_init = True

        from surya.model.detection.model import load_model as _ld, load_processor as _lp
        from surya.model.recognition.model import load_model as _lrm
        from surya.model.recognition.processor import load_processor as _lrp

        _det_model = _ld()
        _det_processor = _lp()
        _rec_model = _lrm()
        _rec_processor = _lrp()
        _surya_loaded = True


def _load_qwen() -> None:
    global _qwen_model, _qwen_processor, _qwen_loaded
    with _qwen_lock:
        if _qwen_loaded:
            return
        import torch
        from transformers import AutoProcessor, Qwen2VLForConditionalGeneration

        _qwen_processor = AutoProcessor.from_pretrained(QWEN_MODEL_ID)
        _qwen_model = Qwen2VLForConditionalGeneration.from_pretrained(
            QWEN_MODEL_ID,
            dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
            device_map="auto",
        )
        _qwen_model.eval()
        _qwen_loaded = True


# ── Helpers ───────────────────────────────────────────────────────────────────

def _pdf_to_images(pdf_path: str, dpi: int = 150) -> List:
    import fitz
    from PIL import Image

    doc = fitz.open(pdf_path)
    images = []
    for page in doc:
        pix = page.get_pixmap(dpi=dpi)
        img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        images.append(img)
    doc.close()
    return images


def _run_surya_ocr(images: List) -> str:
    _load_surya()
    from surya.ocr import run_ocr

    lang_lists = [["en"]] * len(images)
    ocr_results = run_ocr(
        images, lang_lists, _det_model, _det_processor, _rec_model, _rec_processor
    )

    lines: List[str] = []
    for result in ocr_results:
        for tl in result.text_lines:
            text = (tl.text or "").strip()
            if text:
                lines.append(text)
    return "\n".join(lines)


def _extract_json_from_text(text: str) -> Optional[Dict[str, Any]]:
    stripped = text.strip()
    if stripped.startswith("```"):
        first_nl = stripped.find("\n")
        last_fence = stripped.rfind("```")
        if first_nl != -1 and last_fence > first_nl:
            stripped = stripped[first_nl + 1 : last_fence].strip()
    start = stripped.find("{")
    end = stripped.rfind("}")
    if start != -1 and end > start:
        try:
            return json.loads(stripped[start : end + 1])
        except json.JSONDecodeError:
            pass
    return None


def _run_qwen_extraction(images: List, ocr_text: str, form_type: str) -> Dict[str, Any]:
    _load_qwen()
    import torch

    page_images = images[:2]

    prompt = (
        f"You are an expert insurance document parser. "
        f"Extract ALL filled-in fields from this ACORD {form_type} form and return them as a single flat JSON object. "
        f"Use the exact field label from the form as the key and the filled-in value as the value. "
        f"Omit blank or unchecked fields. Return ONLY valid JSON with no explanation."
    )
    if ocr_text.strip():
        prompt += f"\n\nOCR text for reference:\n{ocr_text[:3000]}"

    content: List[Dict[str, Any]] = [
        {"type": "image", "image": img} for img in page_images
    ]
    content.append({"type": "text", "text": prompt})

    messages = [{"role": "user", "content": content}]

    text_input = _qwen_processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )

    image_inputs = [
        item["image"]
        for msg in messages
        if isinstance(msg.get("content"), list)
        for item in msg["content"]
        if item.get("type") == "image"
    ]

    inputs = _qwen_processor(
        text=[text_input],
        images=image_inputs if image_inputs else None,
        padding=True,
        return_tensors="pt",
    )

    device = next(_qwen_model.parameters()).device
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        generated_ids = _qwen_model.generate(**inputs, max_new_tokens=2048)

    trimmed = [out[len(inp):] for inp, out in zip(inputs["input_ids"], generated_ids)]
    output_text = _qwen_processor.batch_decode(
        trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
    )[0]

    parsed = _extract_json_from_text(output_text)
    return parsed if parsed is not None else {"_raw_qwen_output": output_text}


# ── Public entry point ────────────────────────────────────────────────────────

def run_full_extraction(pdf_path: str, form_type: str = "25") -> Dict[str, Any]:
    """
    Full ACORD extraction pipeline.
    Returns: { form_type_detected, pdf_type, extracted_json, full_text }
    """
    if not Path(pdf_path).exists():
        return {"error": f"File not found: {pdf_path}"}

    images = _pdf_to_images(pdf_path)
    if not images:
        return {"error": "No pages found in PDF"}

    ocr_text = _run_surya_ocr(images)
    pdf_type = "digital" if len(ocr_text.strip()) > 100 else "scanned"

    extracted_json = _run_qwen_extraction(images, ocr_text, form_type)

    return {
        "form_type_detected": f"acord{form_type}",
        "pdf_type": pdf_type,
        "extracted_json": extracted_json,
        "full_text": ocr_text,
    }
